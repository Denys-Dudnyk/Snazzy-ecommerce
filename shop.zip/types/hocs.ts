export interface IWrappedComponentProps {
	open: boolean
	setOpen: (arg: boolean) => void
}
