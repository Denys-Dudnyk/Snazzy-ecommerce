export enum AllowedLangs {
	RU = 'ru',
	EN = 'en',
}
