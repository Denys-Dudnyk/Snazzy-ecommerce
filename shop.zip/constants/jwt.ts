export enum JWTError {
	INVALID_JWT_TOKEN = 'JsonWebTokenError',
	EXPIRED_JWT_TOKEN = 'TokenExpiredError',
}
