import axios from 'axios'

export const getContentType = () => ({
	'Content-Type': 'application/json',
})

const instance = axios.create({
	baseURL: process.env.EARTHO_BASE_URL,
	headers: getContentType(),
})

export default instance
