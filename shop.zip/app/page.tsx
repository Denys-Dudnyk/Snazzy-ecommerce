import MainPage from '@/components/tamplates/MainPage/MainPage'
import Image from 'next/image'

export default function Home() {
	return <MainPage />
}
