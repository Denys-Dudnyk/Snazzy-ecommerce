import { handleAccess, handleConnect } from '@eartho/one-client-nextjs'

export const GET = handleAccess({
	login: handleConnect({
		authorizationParams: {
			access_id: '4nXiSFFne9ribXnz74dt',
		},
	}),
})
