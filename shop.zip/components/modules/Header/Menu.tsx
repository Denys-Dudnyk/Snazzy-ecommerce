import Logo from '@/components/elements/Logo'
import { AllowedLangs } from '@/constants/lang'
import { setLang } from '@/context/lang'
import { $menuIsOpen, closeMenu } from '@/context/modals'
import { UseLang } from '@/hooks/useLang'
import { removeOverflowHiddenFromBodyMenu } from '@/lib/utils/common'
import { useUnit } from 'effector-react'
import { AnimatePresence, motion } from 'framer-motion'
import { useState } from 'react'
import Accordion from '../Accordion/Accordion'
import { usePathname } from 'next/navigation'
import MenuLinkItem from './MenuLinkItem'
import Link from 'next/link'
import { useMediaQuery } from '@/hooks/useMediaQuery'
import BuyersListItems from './BuyersListItems/BuyersListItems'
import ContactsListItems from './ContactsListItems/ContactsListItems'

const Menu = () => {
	const [showCatalogList, setShowCatalogList] = useState(false)
	const [showBuyerList, setShowBuyerList] = useState(false)
	const [showContactList, setShowContactList] = useState(false)
	const menuIsOpen = useUnit($menuIsOpen)
	const { lang, translations } = UseLang()
	const pathname = usePathname()
	const isMedia800 = useMediaQuery(800)
	const isMedia640 = useMediaQuery(640)

	const handleSwitchLang = (lang: string) => {
		setLang(lang as AllowedLangs)
		localStorage.setItem('lang', JSON.stringify(lang))
	}

	const handleSwitchLangToRU = () => handleSwitchLang('ru')
	const handleSwitchLangToEN = () => handleSwitchLang('en')

	const handleShowCatalogList = () => {
		setShowCatalogList(true)
		setShowBuyerList(false)
		setShowContactList(false)
	}

	const handleShowBuyersList = () => {
		setShowCatalogList(false)
		setShowBuyerList(true)
		setShowContactList(false)
	}
	const handleShowContactsList = () => {
		setShowCatalogList(false)
		setShowBuyerList(false)
		setShowContactList(true)
	}
	const handleCloseMenu = () => {
		removeOverflowHiddenFromBodyMenu()
		closeMenu()
	}

	const handleRedirectToCatalog = (path: string) => {
		if (pathname.includes('/catalog')) {
			window.history.pushState({ path }, '', path)
			window.location.reload()
		}
		handleCloseMenu()
	}

	const clothLinks = [
		{
			id: 1,
			text: translations[lang].comparison['t-shirts'],
			href: '/catalog/cloth?offset=0&type=t-shirts',
		},
		{
			id: 2,
			text: translations[lang].comparison['long-sleeves'],
			href: '/catalog/cloth?offset=0&type=long-sleeves',
		},
		{
			id: 3,
			text: translations[lang].comparison.hoodie,
			href: '/catalog/cloth?offset=0&type=hoodie',
		},
		{
			id: 4,
			text: translations[lang].comparison.outerwear,
			href: '/catalog/cloth?offset=0&type=outerwear',
		},
	]

	const accessoriesLinks = [
		{
			id: 1,
			text: translations[lang].comparison.bags,
			href: '/catalog/accessories?offset=0&type=bags',
		},
		{
			id: 2,
			text: translations[lang].comparison.headdress,
			href: '/catalog/accessories?offset=0&type=headdress',
		},
		{
			id: 3,
			text: translations[lang].comparison.umbrella,
			href: '/catalog/accessories?offset=0&type=umbrella',
		},
	]

	const souvenirsLinks = [
		{
			id: 1,
			text: translations[lang].comparison['business-souvenirs'],
			href: '/catalog/souvenirs?offset=0&type=business-souvenirs',
		},
		{
			id: 2,
			text: translations[lang].comparison['promotional-souvenirs'],
			href: '/catalog/souvenirs?offset=0&type=promotional-souvenirs',
		},
	]

	const officeLinks = [
		{
			id: 1,
			text: translations[lang].comparison.notebook,
			href: '/catalog/office?offset=0&type=notebook',
		},
		{
			id: 2,
			text: translations[lang].comparison.pen,
			href: '/catalog/office?offset=0&type=pen',
		},
	]

	return (
		<nav className={`nav-menu ${menuIsOpen ? 'open' : 'close'}`}>
			<div className='container nav-menu__container'>
				<div className={`nav-menu__logo ${menuIsOpen ? 'open' : ''}`}>
					<Logo />
				</div>

				<img
					className={`nav-menu__bg ${menuIsOpen ? 'open' : ''}`}
					src={`/img/menu-bg${isMedia800 ? '-small' : ''}.png`}
					alt='menu background'
				/>

				<button
					className={`btn-reset nav-menu__close ${menuIsOpen ? 'open' : ''}`}
					onClick={handleCloseMenu}
				/>
				{/* <div className={`nav-menu__lang ${menuIsOpen ? 'open' : 'close'}`}>
					<button
						className={`btn-reset nav-menu__lang__btn ${lang === 'ru' ? 'lang-active' : ''}`}
						onClick={handleSwitchLangToRU}
					>
						RU
					</button>
					<button
						className={`btn-reset nav-menu__lang__btn ${lang === 'en' ? 'lang-active' : ''}`}
						onClick={handleSwitchLangToEN}
					>
						EN
					</button>
				</div> */}

				<ul className={`list-reset nav-menu__list ${menuIsOpen ? 'open' : ''}`}>
					{!isMedia800 && (
						<li className='nav-menu__list__item'>
							<button
								className='btn-reset nav-menu__list__item__btn'
								onMouseEnter={handleShowCatalogList}
							>
								{translations[lang].main_menu.catalog}
							</button>
							<AnimatePresence>
								{showCatalogList && (
									<motion.ul
										initial={{ opacity: 0 }}
										animate={{ opacity: 1 }}
										exit={{ opacity: 0 }}
										className='list-reset nav-menu__accordion'
									>
										<li className='nav-menu__accordion__item'>
											<Accordion
												title={translations[lang].main_menu.cloth}
												titleClass='btn-reset nav-menu__accordion__item__title'
											>
												<ul className='list-reset nav-menu__accordion__item__list'>
													{clothLinks.map(item => (
														<MenuLinkItem
															key={item.id}
															item={item}
															handleRedirectToCatalog={handleRedirectToCatalog}
														/>
													))}
												</ul>
											</Accordion>
										</li>
										<li className='nav-menu__accordion__item'>
											<Accordion
												title={translations[lang].main_menu.accessories}
												titleClass='btn-reset nav-menu__accordion__item__title'
											>
												<ul className='list-reset nav-menu__accordion__item__list'>
													{accessoriesLinks.map(item => (
														<MenuLinkItem
															key={item.id}
															item={item}
															handleRedirectToCatalog={handleRedirectToCatalog}
														/>
													))}
												</ul>
											</Accordion>
										</li>
										<li className='nav-menu__accordion__item'>
											<Accordion
												title={translations[lang].main_menu.souvenirs}
												titleClass='btn-reset nav-menu__accordion__item__title'
											>
												<ul className='list-reset nav-menu__accordion__item__list'>
													{souvenirsLinks.map(item => (
														<MenuLinkItem
															key={item.id}
															item={item}
															handleRedirectToCatalog={handleRedirectToCatalog}
														/>
													))}
												</ul>
											</Accordion>
										</li>
										<li className='nav-menu__accordion__item'>
											<Accordion
												title={translations[lang].main_menu.office}
												titleClass='btn-reset nav-menu__accordion__item__title'
											>
												<ul className='list-reset nav-menu__accordion__item__list'>
													{officeLinks.map(item => (
														<MenuLinkItem
															key={item.id}
															item={item}
															handleRedirectToCatalog={handleRedirectToCatalog}
														/>
													))}
												</ul>
											</Accordion>
										</li>
									</motion.ul>
								)}
							</AnimatePresence>
						</li>
					)}

					<li className='nav-menu__list__item'>
						{!isMedia640 && (
							<button
								className='btn-reset nav-menu__list__item__btn'
								onMouseEnter={handleShowBuyersList}
							>
								{translations[lang].main_menu.buyers}
							</button>
						)}

						{!isMedia640 && (
							<AnimatePresence>
								{showBuyerList && (
									<motion.ul
										initial={{ opacity: 0 }}
										animate={{ opacity: 1 }}
										exit={{ opacity: 0 }}
										className='list-reset nav-menu__accordion'
									>
										<BuyersListItems />
									</motion.ul>
								)}
							</AnimatePresence>
						)}
						{isMedia640 && (
							<Accordion
								title={translations[lang].main_menu.buyers}
								titleClass='btn-reset nav-menu__list__item__btn'
							>
								<ul className='list__reset nav-menu__accordion__item__list'>
									<BuyersListItems />
								</ul>
							</Accordion>
						)}
					</li>
					<li className='nav-menu__list__item'>
						{!isMedia640 && (
							<button
								className='btn-reset nav-menu__list__item__btn'
								onMouseEnter={handleShowContactsList}
							>
								{translations[lang].main_menu.contacts}
							</button>
						)}

						{!isMedia640 && (
							<AnimatePresence>
								{showContactList && (
									<motion.ul
										initial={{ opacity: 0 }}
										animate={{ opacity: 1 }}
										exit={{ opacity: 0 }}
										className='list-reset nav-menu__accordion'
									>
										<ContactsListItems />
									</motion.ul>
								)}
							</AnimatePresence>
						)}

						{isMedia640 && (
							<Accordion
								title={translations[lang].main_menu.contacts}
								titleClass='btn-reset nav-menu__list__item__btn'
							>
								<ul className='list__reset nav-menu__accordion__item__list'>
									<ContactsListItems />
								</ul>
							</Accordion>
						)}
					</li>
				</ul>
			</div>
		</nav>
	)
}

export default Menu
