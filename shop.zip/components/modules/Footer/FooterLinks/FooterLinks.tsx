const FooterLinks = () => {
	return (
		<div className='footer__links'>
			<span>
				<a href=''>Partners</a>
			</span>
			<span>
				<a href=''>Partnership</a>
			</span>
		</div>
	)
}
export default FooterLinks
